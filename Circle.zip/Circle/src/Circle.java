public class Circle {
    double radius;

    Circle () {
        radius = 0;
    }

    Circle(double initialRadius) {
        radius = initialRadius;
    }
}
