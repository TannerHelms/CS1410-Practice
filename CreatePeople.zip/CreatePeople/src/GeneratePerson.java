public abstract class GeneratePerson {
    public abstract String ToString();
}
