import java.util.ArrayList;
import java.util.Date;

class Student extends Person{
    private String ClassStatus;
    private ArrayList<inputGrades> Grades = new ArrayList<inputGrades>();
    Student(String name, String address, String phone, String email, String classStatus) {
        super(name, address, phone, email);
        this.ClassStatus = classStatus;
    }
    @Override
    public String toString(){
        return "Name: " + getName() + "\nAddress: " + getAddress() + "\nPhone: " + getPhone() + "\nEmail: " + getEmail()
                + "\nClass Status: " + ClassStatus;
    }
}
class inputGrades {
    private String AssignmentName;
    private char[] Answers;
    inputGrades(String AssignmentName, char[] answers) {
        this.AssignmentName = AssignmentName;
        this.Answers = answers;
    }


}