import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

public class MultipleChoiceTest {


    public static void main(String[] args) {
        ArrayList<Student> Grades = new ArrayList<>();
        Student s1 = new Student("bob", new char[]{'A', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'});
        Student s2 = new Student("Charlie", new char[]{'D', 'B', 'A', 'B', 'C', 'A', 'E', 'E', 'A', 'D'});
        Student s3 = new Student("Payton", new char[]{'E', 'D', 'D', 'A', 'C', 'B', 'E', 'E', 'A', 'D'});
        Student s4 = new Student("Billy", new char[]{'C', 'B', 'A', 'E', 'D', 'C', 'E', 'E', 'A', 'D'});
        Student s5 = new Student("Karly", new char[]{'A', 'B', 'D', 'C', 'C', 'D', 'E', 'E', 'A', 'D'});
        Student s6 = new Student("Mark", new char[]{'B', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'});
        Student s7 = new Student("Kelly", new char[]{'B', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'});
        Student s8 = new Student("Tanner", new char[]{'E', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'});
        Grades.add(s1);
        Grades.add(s2);
        Grades.add(s3);
        Grades.add(s4);
        Grades.add(s5);
        Grades.add(s6);
        Grades.add(s7);
        Grades.add(s8);
        char[] keys = {'D', 'B', 'D', 'C', 'C', 'D', 'A', 'E', 'A', 'D'};

        for (int i = 0; i < Grades.size() - 1; i++) {
            int correctCount = 0;
            for (int j = 0; j < Grades.get(i).getLength(); j++) {
                if (Grades.get(i).getIndex(j) == keys[j]){
                    correctCount++;
                }

            }
            Grades.get(i).setNumCorrect(correctCount);

        }
        Grades.sort(Comparator.comparing(Student::getNumCorrect).reversed());
        for (int i = 0; i < Grades.size() - 1; i++) {
            System.out.println(Grades.get(i).getName() + ": " + Grades.get(i).getNumCorrect());
        }


    }
}

class Student{
    private String Name;
    private char [] Answers;
    private int Length;
    private int numCorrect;
    Student (String name, char [] answers) {
        this.Name = name;
        this.Answers = answers;
        this.Length = answers.length;
    }
    String getName(){
        return Name;
    }
    char [] getAnswers(){
        return Answers;
    }
    int getLength() {
        return Length;
    }
    char getIndex(int index){
        return Answers[index];
    }
    void setNumCorrect(int num) {
        numCorrect = num;
    }
    int getNumCorrect(){
        return numCorrect;
    }




}

