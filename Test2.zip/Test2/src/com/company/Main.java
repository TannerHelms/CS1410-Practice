package com.company;

public class Main {

    public static void main(String[] args) {
        int[][][] array = {{{1, 2}, {3, 4}}, {{5, 6},{7, 8}}};
        System.out.println(array[0][0][0]);
        System.out.println(array[1][1][1]);
    }


    private static void test1(){
        int[][] array = {{1, 2}, {3, 4}, {5, 6}};
        int sum = 0;
        for (int i = 0; i < array.length; i++)
            sum += array[i][0];
        System.out.println(sum);
    }
    private static void test2(){
        int [][] array = {{1,2}, {3,4}, {5,6}};
        for (int i = array.length - 1; i > 0; --i ) {
            for (int j = array[i]. length - 1; i > 0; i--) {
                System.out.println(array[i][j]);
            }
        }
    }

}
